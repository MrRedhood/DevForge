# DevForge

## AI-Powered Android Coding Environment

**AI-powered Android coding environment with code editor, AI agents, GitHub, terminal, automation, and cloud APK/AAB builds.**

DevForge is an AI-powered Android development environment that lets you write code, use AI coding agents, work with Git and GitHub, run terminal commands, automate development tasks, and build Android APK/AAB files from your phone.

**Turn an Android phone into a portable development workspace:**

`Code → Ask AI → Run agents → Commit → Build → Download → Ship`

DevForge is designed for developers who want to code and manage software projects directly from Android, while using GitHub and cloud-based builds for the heavier parts of development.

[Download](https://github.com/MrRedhood/DevForge/releases) · [GitHub](https://github.com/MrRedhood/DevForge)

![Android CI](https://github.com/MrRedhood/DevForge/actions/workflows/android.yml/badge.svg)
![Android UI Tests](https://github.com/MrRedhood/DevForge/actions/workflows/ui.yml/badge.svg)

### Keywords

`android` · `android-development` · `android-ide` · `code-editor` · `ai-coding` · `ai-agent` · `ai-development` · `github` · `git` · `terminal` · `developer-tools` · `mobile-development`

---

## Who is DevForge for?

DevForge is built for developers who want a practical Android coding environment without being tied to a desktop computer.

It can be useful for:

- Android developers who want to inspect, edit, and build projects from their phone.
- Web and software developers who need a portable code editor, terminal, Git, and GitHub workflow.
- AI-assisted developers who want AI coding assistance and project-aware AI agents.
- Students and learners who want to practice programming and work with real Git repositories from Android.
- Developers working remotely who need access to their projects when a PC is unavailable.

## What can you do with DevForge?

With DevForge, you can:

- Edit and manage software projects on an Android phone.
- Browse and work with GitHub repositories.
- Use AI to understand and modify project code.
- Run AI agent tasks across your project.
- Use a terminal to run development commands.
- Review Git changes, commits, and diffs.
- Create and manage GitHub repositories.
- Run GitHub Actions builds.
- Build Debug APKs, Release APKs, and Android App Bundles (AAB).
- Download build artifacts and development reports back to your device.
- Create scheduled development automations.

The goal is to keep the development workflow together in one Android application instead of requiring separate apps for coding, AI assistance, Git, GitHub, terminal work, and build delivery.

---

# DEVFORGE

## AI-Powered Android Coding Environment

**Code. Ask AI. Run agents. Build. Ship.**

[Download](https://github.com/MrRedhood/DevForge/releases) · [GitHub](https://github.com/MrRedhood/DevForge)

────────────────────────

## CODE ON ANDROID

A full coding workspace on your phone.

DevForge provides an Android-first editor and project workspace for browsing repositories, editing files, navigating code, and keeping development work together in one application.

![DevForge Editor](docs/screenshots/editor.jpg)

────────────────────────

## AI CODING AGENTS

Ask AI about your project.  
Edit files.  
Run controlled agent tasks.

DevForge includes AI chat, project-aware context, controlled AI actions, and multi-step coding-agent workflows. Mutating actions remain controlled by approval and capability policies.

![DevForge AI Agents](docs/screenshots/agents.jpg)

────────────────────────

## GIT + GITHUB

Clone, edit, commit, inspect,  
and manage GitHub projects.

Work with Git repositories and GitHub-backed workspaces, inspect commits and diffs, browse issues and pull requests, create repositories, and keep code changes close to the Android workflow.

![DevForge GitHub and Files](docs/screenshots/github-files.jpg)

────────────────────────

## TERMINAL

Run development commands  
directly from your Android device.

The direct user terminal provides a real shell surface inside the development workspace. AI terminal execution is separately bounded and approval-controlled.

![DevForge Terminal](docs/screenshots/terminal.jpg)

────────────────────────

## BUILD APK & AAB

Build Android applications  
through GitHub Actions.

- **Debug APK**
- **Release APK**
- **Release AAB / AAB**

Build Center can monitor GitHub Actions runs, surface logs, retrieve build artifacts, and pull enabled development reports back into the app.

![DevForge Build Center](docs/screenshots/build-center.jpg)

────────────────────────

## AUTOMATION

Schedule and run development tasks.

DevForge includes development automations with execution history and approval-aware actions so recurring project work can stay inside the same Android workflow.

────────────────────────

## WHO IS DEVFORGE FOR?

**Android developers**  
**AI developers**  
**Students**  
**Remote developers**  
**Mobile developers**

────────────────────────

## FAQ

### Can I code on Android?

Yes. DevForge provides an Android-based development environment with a code editor, project workspaces, terminal, Git, GitHub integration, AI assistance, and development automation.

### Does DevForge support AI coding?

Yes. DevForge includes AI chat, project-aware AI context, controlled AI actions, and multi-step AI agent workflows for development tasks.

### Can DevForge work with GitHub?

Yes. DevForge can work with GitHub repositories, browse repositories, issues, and pull requests, create repositories, inspect Git history and changes, and work with GitHub-backed projects.

### Can I build an APK on Android?

DevForge's Build Center uses GitHub Actions to build Debug APKs, Release APKs, and Release AABs. Build artifacts and reports can be pulled back into DevForge.

### Is DevForge an Android IDE?

DevForge is an Android-first coding environment that combines code editing, AI-assisted development, Git/GitHub, terminal tools, automation, and Android build workflows in one application.

────────────────────────

## OPEN SOURCE

DevForge is developed in the open on GitHub.

[GitHub](https://github.com/MrRedhood/DevForge)

────────────────────────

## DOWNLOAD DEVFORGE

[Download DevForge](https://github.com/MrRedhood/DevForge/releases)

---

## Current capabilities

### Code and workspaces

- Multiple local workspaces and GitHub-backed repositories.
- Project tree navigation with file and folder creation, editing, renaming, deletion, and refresh.
- Editor tabs, split editor, search, replace, quick open, go-to-line, symbols, folding, problems, breadcrumbs, and local history.
- Broad language detection and syntax-highlighting support.
- Workspace backup and recovery.

### AI development

- Multi-provider AI chat.
- Project-aware workspace context.
- Controlled file mutations through agent tools.
- AI terminal command execution through a bounded allowlist, timeouts, output limits, and approval controls.
- Read-only Git history access through the `get_git_log` agent tool.
- Separate Chat and Agent execution controls.

### Git and GitHub

- Git status, diffs, commits, history, and reversible commit workflows.
- GitHub repository browsing and editing.
- Issues and pull requests.
- Repository creation and in-app repository deletion.
- GitHub-backed workspace editing and commits.

### Build and delivery

- GitHub Actions Build Center.
- Debug APK, Release APK, and Release AAB targets.
- Configurable artifact publication.
- Lint, unit-test, and dependency reports.
- Live workflow status and logs.
- Build artifact download directly to the Android device.

### Automation and safety

- Scheduled development automations.
- Approval-controlled mutating actions.
- Scoped capability grants.
- Bounded tool inputs and outputs.
- Diagnostics, recovery, backup, and quality/reliability checks.

---

## Repository metadata

**Description**

> AI-powered Android coding environment with code editor, AI agents, GitHub, terminal, automation, and cloud APK/AAB builds.

**Keywords**

```
android
android-development
android-ide
code-editor
ai-coding
ai-agent
ai-development
github
git
terminal
developer-tools
mobile-development
```

## Project

[Repository](https://github.com/MrRedhood/DevForge) · [Issues](https://github.com/MrRedhood/DevForge/issues) · [GitHub Actions](https://github.com/MrRedhood/DevForge/actions)
